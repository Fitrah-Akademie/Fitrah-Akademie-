(() => {
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", () => navigator.serviceWorker.register("/static/sw.js").catch(() => {}));
  }
  let installPrompt = null;
  const button = document.getElementById("install-app");
  window.addEventListener("beforeinstallprompt", event => { event.preventDefault(); installPrompt = event; if (button) button.hidden = false; });
  if (button) button.addEventListener("click", async () => {
    if (!installPrompt) { alert("على الهاتف: افتح قائمة المتصفح واختر «إضافة إلى الشاشة الرئيسية» أو «تثبيت التطبيق»."); return; }
    installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; button.hidden = true;
  });
  window.addEventListener("appinstalled", () => { if (button) button.hidden = true; });
})();
