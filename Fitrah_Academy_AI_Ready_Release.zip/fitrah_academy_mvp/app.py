import os, sqlite3, secrets, json, urllib.request, urllib.error
from datetime import datetime
from functools import wraps
from flask import Flask, request, redirect, url_for, session, g, render_template, abort, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from markupsafe import escape
from authlib.integrations.flask_client import OAuth

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "fitrah_academy.db"))
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
if os.environ.get("TRUST_PROXY_HEADERS", "0") == "1":
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
oauth = OAuth(app)
if os.environ.get("GOOGLE_CLIENT_ID") and os.environ.get("GOOGLE_CLIENT_SECRET"):
    oauth.register(
        name="google", client_id=os.environ["GOOGLE_CLIENT_ID"],
        client_secret=os.environ["GOOGLE_CLIENT_SECRET"],
        server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
        client_kwargs={"scope": "openid email profile"},
    )
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=8 * 1024 * 1024,
)

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student' CHECK(role IN ('student','admin','teacher')),
      language TEXT NOT NULL DEFAULT 'ar' CHECK(language IN ('ar','en')),
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL, subject TEXT NOT NULL, level TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '', published INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL, level TEXT NOT NULL, pdf_url TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      lesson_time TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      question TEXT NOT NULL, option_a TEXT NOT NULL, option_b TEXT NOT NULL,
      option_c TEXT NOT NULL, correct_answer TEXT NOT NULL CHECK(correct_answer IN ('a','b','c')),
      subject TEXT NOT NULL DEFAULT 'عام'
    );
    CREATE TABLE IF NOT EXISTS results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      score INTEGER NOT NULL, total INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS leads (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL,
      interest TEXT NOT NULL DEFAULT '', language TEXT NOT NULL DEFAULT 'ar',
      consent INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS ai_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, feature TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    """)
    db.commit()
    admin_name = os.environ.get("ADMIN_USERNAME", "admin").strip()
    admin_password = os.environ.get("ADMIN_PASSWORD", "")
    if admin_password and len(admin_password) >= 12:
        exists = db.execute("SELECT id FROM users WHERE username=?", (admin_name,)).fetchone()
        if not exists:
            db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                       (admin_name, generate_password_hash(admin_password), "admin"))
            db.commit()

@app.before_request
def setup_database():
    init_db()
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(24)

def csrf_valid():
    return secrets.compare_digest(str(request.form.get("_csrf", "")), str(session.get("csrf_token", "")))

@app.context_processor
def inject_globals():
    return {"year": datetime.now().year, "csrf_token": session.get("csrf_token", "")}

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("سجّل الدخول أولًا للمتابعة.", "info")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def role_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if session.get("role") not in roles:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return deco

def check_csrf():
    if not csrf_valid():
        abort(400, "انتهت صلاحية النموذج. أعد تحميل الصفحة وحاول مرة أخرى.")

def ai_is_configured():
    return bool(os.environ.get("AI_API_KEY") and os.environ.get("AI_MODEL"))

def call_ai(system_prompt, user_prompt):
    """Optional OpenAI-compatible endpoint. No request is sent unless an admin configures a key."""
    api_key = os.environ.get("AI_API_KEY", "").strip()
    model = os.environ.get("AI_MODEL", "").strip()
    base_url = os.environ.get("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    if not api_key or not model:
        return None, "مساعد الذكاء الاصطناعي غير موصول بعد. يلزم إعداد مزوّد ومفتاح API في متغيرات البيئة؛ لا تضع المفتاح داخل الكود أو ترسله في المحادثة."
    payload = json.dumps({"model": model, "messages": [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt[:6000]},
    ], "temperature": 0.5}).encode("utf-8")
    req = urllib.request.Request(base_url + "/chat/completions", data=payload, headers={
        "Authorization": "Bearer " + api_key, "Content-Type": "application/json"
    }, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=35) as response:
            data = json.loads(response.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"], None
    except (urllib.error.URLError, urllib.error.HTTPError, KeyError, ValueError, TimeoutError):
        app.logger.exception("AI provider request failed")
        return None, "تعذّر الاتصال بمزوّد الذكاء الاصطناعي. راجع إعدادات الخدمة أو حاول لاحقًا."

@app.route("/robots.txt")
def robots():
    return "User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /dashboard\nDisallow: /ai-tutor\nSitemap: " + request.url_root.rstrip("/") + "/sitemap.xml\n", 200, {"Content-Type":"text/plain; charset=utf-8"}

@app.route("/sitemap.xml")
def sitemap():
    urls = [url_for("home", _external=True), url_for("courses", _external=True), url_for("books", _external=True), url_for("pricing", _external=True)]
    body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">" + "".join("<url><loc>" + escape(u) + "</loc></url>" for u in urls) + "</urlset>"
    return body, 200, {"Content-Type":"application/xml; charset=utf-8"}

@app.route("/")
def home():
    courses = get_db().execute("SELECT * FROM courses WHERE published=1 ORDER BY id DESC LIMIT 3").fetchall()
    return render_template("home.html", courses=courses)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        check_csrf()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        language = request.form.get("language", "ar")
        if len(username) < 3 or len(username) > 40 or len(password) < 10:
            flash("اسم المستخدم من 3 إلى 40 حرفًا، وكلمة المرور 10 أحرف على الأقل.", "error")
        elif language not in ("ar", "en"):
            flash("اختيار اللغة غير صالح.", "error")
        else:
            try:
                get_db().execute("INSERT INTO users(username,password_hash,language) VALUES(?,?,?)",
                                 (username, generate_password_hash(password), language))
                get_db().commit()
                flash("تم إنشاء الحساب. يمكنك تسجيل الدخول الآن.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("اسم المستخدم مستخدم بالفعل.", "error")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        check_csrf()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["csrf_token"] = secrets.token_urlsafe(24)
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            session["language"] = user["language"]
            return redirect(url_for("dashboard"))
        flash("اسم المستخدم أو كلمة المرور غير صحيحة.", "error")
    return render_template("auth.html", mode="login")

@app.route("/login/google")
def login_google():
    client = oauth.create_client("google")
    if not client:
        flash("تسجيل الدخول بواسطة Google لم يُفعّل بعد. يحتاج إعداد OAuth Client ID وClient Secret في إعدادات الخادم.", "info")
        return redirect(url_for("login"))
    redirect_uri = url_for("google_callback", _external=True, _scheme="https" if request.is_secure else "http")
    return client.authorize_redirect(redirect_uri)

@app.route("/auth/google/callback")
def google_callback():
    client = oauth.create_client("google")
    if not client:
        flash("تسجيل الدخول بواسطة Google غير مهيأ.", "error")
        return redirect(url_for("login"))
    try:
        token = client.authorize_access_token()
        info = token.get("userinfo") or client.userinfo()
    except Exception:
        app.logger.exception("Google OAuth callback failed")
        flash("تعذّر تسجيل الدخول بواسطة Google. تحقق من إعداد OAuth وعنوان العودة.", "error")
        return redirect(url_for("login"))
    email = (info.get("email") or "").strip().lower()
    if not email or not info.get("email_verified", False):
        flash("يلزم بريد Google موثّق لإكمال تسجيل الدخول.", "error")
        return redirect(url_for("login"))
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE username=?", (email,)).fetchone()
    if not user:
        db.execute("INSERT INTO users(username,password_hash,role,language) VALUES(?,?,?,?)",
                   (email, generate_password_hash(secrets.token_urlsafe(32)), "student", "ar"))
        db.commit()
        user = db.execute("SELECT * FROM users WHERE username=?", (email,)).fetchone()
    session.clear()
    session["csrf_token"] = secrets.token_urlsafe(24)
    session["user_id"] = user["id"]
    session["username"] = user["username"]
    session["role"] = user["role"]
    session["language"] = user["language"]
    return redirect(url_for("dashboard"))

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    check_csrf()
    session.clear()
    flash("تم تسجيل الخروج.", "success")
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    bookings = db.execute("""SELECT b.*, c.title FROM bookings b JOIN courses c ON c.id=b.course_id
                             WHERE b.student_id=? ORDER BY b.id DESC""", (session["user_id"],)).fetchall()
    results = db.execute("SELECT * FROM results WHERE student_id=? ORDER BY id DESC LIMIT 5",
                         (session["user_id"],)).fetchall()
    return render_template("dashboard.html", bookings=bookings, results=results)

@app.route("/courses")
def courses():
    items = get_db().execute("SELECT * FROM courses WHERE published=1 ORDER BY id DESC").fetchall()
    return render_template("courses.html", courses=items)

@app.route("/books")
def books():
    items = get_db().execute("SELECT * FROM books ORDER BY id DESC").fetchall()
    return render_template("books.html", books=items)

@app.route("/book/<int:course_id>", methods=["GET", "POST"])
@login_required
def book_lesson(course_id):
    db = get_db()
    course = db.execute("SELECT * FROM courses WHERE id=? AND published=1", (course_id,)).fetchone()
    if not course:
        abort(404)
    if request.method == "POST":
        check_csrf()
        lesson_time = request.form.get("lesson_time", "").strip()
        if not lesson_time:
            flash("اختر موعدًا مقترحًا.", "error")
        else:
            db.execute("INSERT INTO bookings(student_id,course_id,lesson_time) VALUES(?,?,?)",
                       (session["user_id"], course_id, lesson_time))
            db.commit()
            flash("وصل طلب الحجز للإدارة للمراجعة.", "success")
            return redirect(url_for("dashboard"))
    return render_template("booking.html", course=course)

@app.route("/placement-test", methods=["GET", "POST"])
@login_required
def placement_test():
    db = get_db()
    questions = db.execute("SELECT * FROM questions ORDER BY id").fetchall()
    if request.method == "POST":
        check_csrf()
        if not questions:
            flash("لم يضف الفريق أسئلة الاختبار بعد.", "info")
            return redirect(url_for("placement_test"))
        score = sum(1 for q in questions if request.form.get(str(q["id"])) == q["correct_answer"])
        db.execute("INSERT INTO results(student_id,score,total) VALUES(?,?,?)",
                   (session["user_id"], score, len(questions)))
        db.commit()
        return render_template("test_result.html", score=score, total=len(questions))
    return render_template("placement.html", questions=questions)

@app.route("/ai-tutor", methods=["GET", "POST"])
@login_required
def ai_tutor():
    answer = None
    error = None
    if request.method == "POST":
        check_csrf()
        question = request.form.get("question", "").strip()
        if not question or len(question) > 3000:
            error = "اكتب سؤالًا واضحًا لا يتجاوز 3000 حرف."
        else:
            answer, error = call_ai(
                "أنت مساعد تعليمي مهذب لأكاديمية فطرة. أجب بلغة المستخدم وبأسلوب مناسب للعمر. "
                "في المسائل الشرعية وضّح أن الإجابة التعليمية العامة ليست فتوى، ولا تخترع آيات أو أحاديث أو مراجع. "
                "إذا لم تكن متأكدًا فقل ذلك واطلب مراجعة معلّم مؤهل. لا تطلب بيانات شخصية من الأطفال.", question)
            if answer:
                get_db().execute("INSERT INTO ai_logs(user_id,feature) VALUES(?,?)", (session["user_id"], "tutor"))
                get_db().commit()
    return render_template("ai_tutor.html", answer=answer, error=error, configured=ai_is_configured())

@app.route("/pricing")
def pricing():
    plans = [
        {"name":"استكشف", "price":"مجاني", "features":["الوصول إلى الدورات المجانية", "اختبار تحديد المستوى", "مكتبة الموارد المجانية"], "url":os.environ.get("CHECKOUT_FREE_URL", "")},
        {"name":"المتعلم", "price":os.environ.get("PLAN_STUDENT_PRICE", "يُحدد لاحقًا"), "features":["مسارات تعليمية منظمة", "متابعة التقدم", "محتوى إضافي عند توفره"], "url":os.environ.get("CHECKOUT_STUDENT_URL", "")},
        {"name":"العائلة", "price":os.environ.get("PLAN_FAMILY_PRICE", "يُحدد لاحقًا"), "features":["مسارات متعددة لأفراد الأسرة", "تقارير متابعة عند تفعيلها", "دعم تعليمي بحسب الخطة"], "url":os.environ.get("CHECKOUT_FAMILY_URL", "")},
    ]
    return render_template("pricing.html", plans=plans)

@app.route("/join-newsletter", methods=["POST"])
def join_newsletter():
    check_csrf()
    name = request.form.get("name", "").strip()[:100]
    email = request.form.get("email", "").strip()[:254]
    interest = request.form.get("interest", "").strip()[:200]
    language = request.form.get("language", "ar")
    consent = request.form.get("consent") == "yes"
    if not name or "@" not in email or not consent or language not in ("ar", "en"):
        flash("أدخل الاسم والبريد الصحيح ووافق على استلام تحديثات الأكاديمية.", "error")
        return redirect(url_for("home") + "#join")
    get_db().execute("INSERT INTO leads(name,email,interest,language,consent) VALUES(?,?,?,?,1)", (name,email,interest,language))
    get_db().commit()
    flash("شكرًا لاهتمامك! تم تسجيل طلبك. لن نرسل رسائل تسويقية إلا وفق موافقتك.", "success")
    return redirect(url_for("home") + "#join")

@app.route("/admin/marketing", methods=["GET", "POST"])
@login_required
@role_required("admin")
def marketing_studio():
    draft = None
    error = None
    if request.method == "POST":
        check_csrf()
        topic = request.form.get("topic", "").strip()[:1000]
        language = request.form.get("language", "ar")
        channel = request.form.get("channel", "social")
        if not topic:
            error = "اكتب موضوع الحملة أو الدورة أولًا."
        else:
            channel_label = {"social":"منشور اجتماعي", "email":"رسالة بريدية", "partner":"عرض شراكة"}.get(channel, "منشور")
            draft, error = call_ai(
                "أنت مساعد تسويق مسؤول لأكاديمية تعليمية إسلامية. لا تختلق أرقامًا أو شهادات أو شراكات أو نتائج. "
                "تجنب الوعود المضللة والضغط على الجمهور، ولا تستهدف الأطفال مباشرة بطلب بيانات. اكتب دعوة واضحة ومحترمة.",
                f"أنشئ {channel_label} باللغة {language} للأكاديمية حول: {topic}. أعطني عنوانًا ونصًا ودعوة لاتخاذ إجراء و3 وسوم مناسبة.")
    leads = get_db().execute("SELECT * FROM leads ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("marketing.html", draft=draft, error=error, configured=ai_is_configured(), leads=leads)

@app.route("/admin")
@login_required
@role_required("admin")
def admin():
    db = get_db()
    counts = {
        "users": db.execute("SELECT COUNT(*) n FROM users").fetchone()["n"],
        "courses": db.execute("SELECT COUNT(*) n FROM courses").fetchone()["n"],
        "bookings": db.execute("SELECT COUNT(*) n FROM bookings").fetchone()["n"],
        "questions": db.execute("SELECT COUNT(*) n FROM questions").fetchone()["n"],
        "leads": db.execute("SELECT COUNT(*) n FROM leads").fetchone()["n"],
    }
    bookings = db.execute("""SELECT b.*, u.username, c.title FROM bookings b
       JOIN users u ON u.id=b.student_id JOIN courses c ON c.id=b.course_id ORDER BY b.id DESC LIMIT 30""").fetchall()
    return render_template("admin.html", counts=counts, bookings=bookings)

@app.route("/admin/courses", methods=["GET", "POST"])
@login_required
@role_required("admin")
def manage_courses():
    db = get_db()
    if request.method == "POST":
        check_csrf()
        title = request.form.get("title", "").strip()
        subject = request.form.get("subject", "").strip()
        level = request.form.get("level", "").strip()
        description = request.form.get("description", "").strip()
        if title and subject and level:
            db.execute("INSERT INTO courses(title,subject,level,description) VALUES(?,?,?,?)",
                       (title, subject, level, description))
            db.commit()
            flash("تمت إضافة الدورة.", "success")
            return redirect(url_for("manage_courses"))
        flash("أكمل عنوان الدورة والمادة والمستوى.", "error")
    courses = db.execute("SELECT * FROM courses ORDER BY id DESC").fetchall()
    return render_template("admin_courses.html", courses=courses)

@app.route("/admin/books", methods=["GET", "POST"])
@login_required
@role_required("admin")
def manage_books():
    db = get_db()
    if request.method == "POST":
        check_csrf()
        title = request.form.get("title", "").strip()
        level = request.form.get("level", "").strip()
        pdf_url = request.form.get("pdf_url", "").strip()
        description = request.form.get("description", "").strip()
        if title and level and pdf_url.startswith(("https://", "http://")):
            db.execute("INSERT INTO books(title,level,pdf_url,description) VALUES(?,?,?,?)",
                       (title, level, pdf_url, description))
            db.commit()
            flash("تمت إضافة الكتاب.", "success")
            return redirect(url_for("manage_books"))
        flash("أدخل العنوان والمستوى ورابطًا يبدأ بـ http:// أو https://.", "error")
    books = db.execute("SELECT * FROM books ORDER BY id DESC").fetchall()
    return render_template("admin_books.html", books=books)

@app.route("/admin/questions", methods=["GET", "POST"])
@login_required
@role_required("admin")
def manage_questions():
    db = get_db()
    if request.method == "POST":
        check_csrf()
        q = request.form.get("question", "").strip()
        a = request.form.get("a", "").strip()
        b = request.form.get("b", "").strip()
        c = request.form.get("c", "").strip()
        correct = request.form.get("correct", "")
        subject = request.form.get("subject", "عام").strip()
        if q and a and b and c and correct in ("a","b","c"):
            db.execute("INSERT INTO questions(question,option_a,option_b,option_c,correct_answer,subject) VALUES(?,?,?,?,?,?)",
                       (q,a,b,c,correct,subject))
            db.commit()
            flash("تمت إضافة السؤال.", "success")
            return redirect(url_for("manage_questions"))
        flash("أكمل السؤال والخيارات وحدد الإجابة الصحيحة.", "error")
    questions = db.execute("SELECT * FROM questions ORDER BY id DESC").fetchall()
    return render_template("admin_questions.html", questions=questions)

@app.route("/admin/bookings/<int:booking_id>/<status>", methods=["POST"])
@login_required
@role_required("admin")
def update_booking(booking_id, status):
    check_csrf()
    if status not in ("approved", "rejected", "pending"):
        abort(400)
    db = get_db()
    db.execute("UPDATE bookings SET status=? WHERE id=?", (status, booking_id))
    db.commit()
    flash("تم تحديث حالة الحجز.", "success")
    return redirect(url_for("admin"))

@app.errorhandler(403)
def forbidden(error):
    return render_template("error.html", code=403, message="ليس لديك صلاحية للوصول إلى هذه الصفحة."), 403

@app.errorhandler(404)
def not_found(error):
    return render_template("error.html", code=404, message="الصفحة المطلوبة غير موجودة."), 404

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
